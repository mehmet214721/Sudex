function searchCase() {
    let searchQuery = document.getElementById('search').value;
    let resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '<p>Arama sonucu bulunamadı.</p>'; // Basit demo
}
